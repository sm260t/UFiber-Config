# Helper functions

def sample_helper():
    pass