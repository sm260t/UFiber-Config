# UFiber Config Automation

This project contains scripts and configuration files for automating UFiber ONU setups.